import { IMailProvider } from '../providers/IMailProvider';
import logger from '../lib/logger';

export interface OrderNotificationItem {
  name: string;
}

export class NotificationService {
  constructor(private readonly mailProvider: IMailProvider) {}

  async sendOrderConfirmation(
    customer: string,
    orderId: number,
    totalAmount: number,
    items: OrderNotificationItem[]
  ): Promise<string | false> {
    const { previewUrl } = await this.mailProvider.sendMail({
      from: '"DevStore" <noreply@devstore.com>',
      to: customer,
      subject: `Confirmação do Pedido #${orderId}`,
      text: `Olá, seu pedido #${orderId} no valor de R$ ${totalAmount} foi confirmado.`,
      html: `
        <h1>Pedido Confirmado!</h1>
        <p>Olá, seu pedido <b>#${orderId}</b> foi processado com sucesso.</p>
        <p>Total: <strong>R$ ${totalAmount}</strong></p>
        <ul>
          ${items.map(item => `<li>${item.name}</li>`).join('')}
        </ul>
      `,
    });

    logger.info(`Email enviado: ${previewUrl}`);
    return previewUrl;
  }
}
