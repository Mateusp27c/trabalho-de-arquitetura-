import { Product } from './IProduct';

export class PhysicalProduct implements Product {
  readonly type = 'physical';

  constructor(
    readonly id: number,
    readonly name: string,
    readonly price: number,
    readonly weight?: number,
    readonly dimensions?: string
  ) {}

  calculateFreight(): number {
    return 10;
  }
}
